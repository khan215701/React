import React, {useState, Fragment} from 'react';
import User from './components/Users/User';
import UserList from './components/Users/UserList';

function App() {
  const [userList,  setUserList] = useState([])
  const userListHandler = (uName, uAge) => {
    setUserList((prevUserList) => {
      return [...prevUserList, {name: uName, age: uAge, id:Math.random().toString()}]
    })
  }
  return (
    <Fragment>
      <User onUserAdd = {userListHandler}/>
      <UserList users = {userList}/>
    </Fragment>
  );
}

export default App;
