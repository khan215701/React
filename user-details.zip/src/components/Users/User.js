import { useState } from "react";
import Card from "../UI/Card";
import Button from "../UI/Button";
import style from "./User.module.css";
import ErrorMessage from "../UI/ErrorMessage";
import Wrapper from '../helper/wrapper'
const User = (props) => {
  const [username, setUserName] = useState("");
  const [age, setAge] = useState("");
  const [error, setError] = useState("");
  const userHandle = (event) => {
    event.preventDefault();
    if (username.trim().length === 0 || age.trim().length === 0) {
      setError({
        title: "Invalid Input",
        message: "please enter username or age",
      });
      return;
    }
    if (+age < 1) {
      setError({
        title: "Invalid Input",
        message: "please enter age greter 1",
      });
      return;
    }
    props.onUserAdd(username, age);
    setUserName("");
    setAge("");
  };
  const usernameHandler = (event) => {
    setUserName(event.target.value);
  };
  const ageHandler = (event) => {
    setAge(event.target.value);
  };

  const errorHandler = () => {
    setError(null);
  };
  return (
    <Wrapper>
      {error && (
        <ErrorMessage
          title={error.title}
          message={error.message}
          onConfirm={errorHandler}
        />
      )}
      <Card className={style.input}>
        <form onSubmit={userHandle}>
          <label htmlFor="">UserName: </label>
          <input
            id="username"
            type="text"
            value={username}
            onChange={usernameHandler}
          ></input>
          <label htmlFor="">age: </label>
          <input
            id="age"
            type="number"
            value={age}
            onChange={ageHandler}
          ></input>
          <Button type="submit">AddUser</Button>
        </form>
      </Card>
    </Wrapper>
  );
};

export default User;
