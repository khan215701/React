import style from "./ErrorMessage.module.css";
import Card from "./Card";
import Button from "./Button";
import React from "react";
import ReactDOM  from "react-dom";

const BackDrop = (props) => {
  return <div className={style.backdrop} onClick={props.onConfirm} />;
};

const Modaloverlay = (props) => {
  return (
    <Card className={style.modal}>
      <header className={style.header}>{props.title}</header>
      <div className={style.content}>{props.message}</div>
      <footer className={style.actions}>
        <Button onClick={props.onConfirm}>Okay</Button>
      </footer>
    </Card>
  );
};

const ErrorMessage = (props) => {
  return (
    <React.Fragment>
      {ReactDOM.createPortal(
        <BackDrop onConfirm={props.onConfirm} />,
        document.getElementById("backdrop-root")
      )}
      {ReactDOM.createPortal(
        <Modaloverlay
          title={props.title}
          message={props.message}
          onConfirm={props.onConfirm}
        />,
        document.getElementById("error-modal-root")
      )}
    </React.Fragment>
  );
};

export default ErrorMessage;
