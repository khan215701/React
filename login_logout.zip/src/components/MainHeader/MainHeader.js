import React from 'react';
import AuthContext from '../../context/auth-context';
import Navigation from './Navigation';
import classes from './MainHeader.module.css';
import { useContext } from 'react/cjs/react.production.min';

const MainHeader = (props) => {
  const ctx = useContext(AuthContext)
  return (
    <header className={classes['main-header']}>
      <h1>A Typical Page</h1>
      <Navigation isLoggedIn={props.isAuthenticated} onLogout={props.onLogout} />
    </header>
  );
};

export default MainHeader;
