import React, {useState} from 'react';
import './App.css';
import Expenses from './components/Expenses/Expenses';
import NewExpense from './components/NewExpense/NewExpense';

function App() {
  const dummy_data = [
    {
      id : 1,
      title: 'Car Insurance',
      date : new Date(2022, 5 , 1),
      amount : 297.45
    },
    {
      id : 2,
      title: 'Grocery',
      date : new Date(2022, 6 , 3),
      amount : 27.45
    },
    {
      id : 3,
      title: 'Maintainance',
      date : new Date(2022, 7 , 3),
      amount : 100.00
    },  
]

  const [expense, setExpense] = useState(dummy_data)
  const addExpenseHandler = (expenses) => {
    setExpense((prevExpense) => {
      return [expenses, ...prevExpense];
    });
  };
  return (
    <div className=''>
      <NewExpense onAddExpense = {addExpenseHandler}/>
      <Expenses items = {expense}/>
   </div>
  );
}

export default App;
