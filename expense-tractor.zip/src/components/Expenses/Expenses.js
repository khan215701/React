import ExpenseItem from "./ExpenseItem";
import "./Expenses.css";
import Card from "../UI/Card";
import ExpenseFilter from "./ExpenseFilter";
import ExpenseList from "./ExpenseList";
import ExpensesChart from "./ExpenseChart";
import React, { useState } from "react";
function Expenses(props) {
  const [filterYear, setFilterYear] = useState("2022");
  const filterChangeHandler = (selectedYear) => {
    setFilterYear(selectedYear);
  };

  const filteredExpense = props.items.filter(expense =>{
    return expense.date.getFullYear().toString() === filterYear;
});
  
  return (
    <Card className="expenses">
      <ExpenseFilter
        selected={filterYear}
        onChangeFilter={filterChangeHandler}
      />
      <ExpensesChart expense={filteredExpense} />
      <ExpenseList items={filteredExpense}/>
    </Card>
  );
}

export default Expenses;
